# START HERE: The disABLED Company

**Executive summary:** This is the one page to open. It says what was built on Oct 15, 2026, how to talk to your agents, and what's next. You don't need to remember anything else: your Chief of Staff keeps this page current.

---

## 1. Rule #1: you talk only to your Chief of Staff
**He assigns every task to the team and brings you the finished work.** You never talk to the other agents.

**How:** open the `disabled-company` folder in Claude Code and just type. Whatever you type goes to him. You don't need to say his name.
- "Give me my daily brief."
- "Plan my week."
- "What's next on the revenue plan?"
- "Write my Tuesday post." (He hands it to marketing.)
- "Am I on track?" (He hands it to the CFO.)

## 2. Your team
| Agent | Does |
|---|---|
| Chief of Staff (he) | The only one you talk to. Daily brief, Sunday plan, assigns all work |
| CFO | Revenue plan, prices, Friday numbers |
| Head of Marketing | Posts, workbook launch, email list |
| Medical Research Lead | Fact-checks health content, IBM research updates |
| Brand Guardian | Checks everything before it goes public |
| Week Planner | Your week at 4 hours a day |

## 3. Running on its own
- **Every Friday, 9:56 a.m.:** CFO revenue check, sent to your phone and email.

## 4. What was built (all in this folder)
| What | File |
|---|---|
| Employee handbook | `CLAUDE.md` |
| Company facts (prices, links, stats) | `context/company-facts.md` |
| Revenue plan to $50K | `revenue/2026-10-15-revenue-plan.md` |
| CFO interview (done) | `revenue/cfo-interview.md` |
| CASp certification plan | `revenue/2026-10-15-accessibility-certification-track.md` |
| CASp application draft | `revenue/2026-10-15-casp-work-experience-draft.md` |
| 10 target organizations | `pitches/2026-10-15-ops-project-target-list.md` |
| *Be Heard* workbook text | `content/2026-10-15-be-heard-workbook-draft-v1.md` |
| *Be Heard* workbook design (Canva) | https://canva.link/f9ec40tpibojzlr |
| AI & healthcare talk | `content/2026-10-15-ai-healthcare-talk-outline.md` |
| Speaking page update | `website/2026-10-15-speaking-page-update.md` |
| Records Command Center page | `website/2026-10-15-records-command-center-page.md` |
| Store fixes | `website/2026-10-15-store-fixes-sop.md` |

## 5. Your to-do (only things only you can do)
1. Fix the ZenBusiness payment (log in, go to Billing, update your card).
2. Say yes or no to each of the 10 organizations in the target list.
3. Review the *Be Heard* workbook in Canva.
4. Find your Oakland offer letter or W-2s for the CASp application (apply by Dec 15).
5. Post the Tuesday tee post, Friday talk post and TMA post when you're ready.

Everything else is the team's job.

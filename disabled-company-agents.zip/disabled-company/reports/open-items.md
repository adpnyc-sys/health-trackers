# Open Items (the Chief of Staff's running list)

**Executive summary:** Every unfinished task from Oct 15, 2026, for Alicia and for the team, checked line by line against the whole day's work. The Chief of Staff reads this before every daily brief, puts Alicia's most urgent items on her Day List (within her 4 hours), assigns the team items, and moves items to Done when they're finished. Alicia never has to track any of this herself.

---

## Alicia (only she can do these)
| # | Task | Due | Why it matters |
|---|---|---|---|
| A1 | Fix the ZenBusiness payment (log in → Billing → update card) | ASAP | Three "payment failed" notices; could affect the LLC's services |
| A2 | Mark yes or no on the 10 organizations (`pitches/2026-10-15-ops-project-target-list.md`) | Oct 22 | Unlocks the $30,000 Ops projects |
| A3 | Review the *Be Heard* workbook in Canva: https://canva.link/f9ec40tpibojzlr | Oct 24 | Workbook launch in November |
| A4 | Post the Tuesday tee post, Friday talk post and TMA post (add the tee link to the Instagram bio first) | Next Tue/Fri | Revenue and TMA cadence |
| A5 | Approve the speaking page draft (`website/2026-10-15-speaking-page-update.md`) | Oct 31 | The AI talk needs a page to sell from |
| A6 | Records Command Center page: set the turnaround time and how records are stored and deleted (`website/2026-10-15-records-command-center-page.md`) | Oct 31 | $10,500 offer needs a page; privacy must be right |
| A7 | Fix the store: duplicate listings, Facebook links, "Shop" menu (`website/2026-10-15-store-fixes-sop.md`, about 45 min) | Oct 31 | The store looks unfinished to buyers |
| A8 | Inbox triage setup: which Outlook account, and where alicia@thedisabledcompany.com lives | Oct 22 | So the daily brief covers every inbox |
| A9 | Send current follower counts (Instagram, Facebook) | Oct 22 | Stats are out of date; needed before any pitch |
| A10 | Set a new follower goal and date, and where email signups should go | Oct 31 | The old 222,222 goal has passed |
| A11 | Confirm the website hosting cost and whether Claude Pro is a business cost | Oct 31 | Accurate costs for the CFO |
| A12 | Name your affiliate networks, if any | Oct 31 | So the Friday revenue check can find payouts |
| A13 | Finish CPACC (your 3-week goal) | ~Nov 5 | Credibility for accessibility consulting |
| A14 | Buy and schedule the ICC Accessibility Inspector/Plans Examiner exam ($320) | Nov | Lets you sell accessibility surveys from January |
| A15 | Find the Oakland offer letter or W-2s (exact months, employer of record, title) | Dec 1 | CASp eligibility |
| A16 | Submit the CASp application ($500) | Dec 15 | Calendar reminder set |
| A17 | Register for the Feb 5 & 8 CASp exams ($500) | Jan 15 | Calendar reminder set |
| A18 | Export the book's companion workbook from ChatGPT and drop it in the project | When ready | Reuse its design and pages |
| A19 | Optional: say yes to emailing 3 CASps for price quotes | When ready | Real market prices for surveys and CASp |
| A20 | Pick one brand palette (navy/teal/gold or black/gold) | When ready | Consistent look across products |

## Team (no Alicia time needed)
| # | Task | Owner | Due |
|---|---|---|---|
| T1 | Find people Alicia already knows at each "yes" organization | Chief of Staff | After A2 |
| T2 | Draft one short email per "yes" organization, plus a one-page project overview, for Alicia's yes | Chief of Staff | After T1 |
| T3 | Check the Canva workbook page by page against the text draft | Head of Marketing | Oct 22 |
| T4 | Workbook store setup: step-by-step for selling it as a digital download | Head of Marketing | After A3 |
| T5 | Build the `follow-up-tracker` skill; first item: Kizik follow-up draft (pitch sent, no reply) | Chief of Staff | Oct 31 |
| T6 | Build the AI talk speaker sheet in Canva | Head of Marketing | Oct 31 |
| T7 | Draft next week's Tuesday, Friday and TMA posts | Head of Marketing | Every Thursday |
| T8 | First monthly IBM/IIM research update | Medical Research Lead | Nov 15 |
| T9 | Monthly CFO deep dive on the revenue plan | CFO | Nov 15 |
| T10 | Friday revenue check (scheduled, runs on its own) | CFO | Every Friday |
| T11 | CPACC and CASp practice quizzes, focused on missed topics | Chief of Staff | On request |
| T12 | Walk Alicia through locking connector permissions so "draft only" is enforced | Chief of Staff | Nov |
| T13 | Later hires: pitch writer, sponsorship scout, opportunity scout, job search (5 applications/week) | Chief of Staff | Propose when work repeats |

## Done (Oct 15, 2026)
- Handbook with Rule #1, 6 agents, 2 skills, company facts
- CFO interview (12/12), revenue plan, talk fees, Records Command Center price
- CASp plan, CASp application draft, calendar reminders (Dec 15, Jan 15)
- 10-organization target list
- *Be Heard* workbook text and Canva design
- AI talk outline, speaking page and Records Command Center page drafts, store-fix SOP
- Tuesday, Friday and TMA post drafts
- CPACC/CASp practice quizzes, rounds 1–3
- Friday revenue check scheduled

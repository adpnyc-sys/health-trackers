# Accessibility Inspection Certification Track

**Executive summary:** The strongest credential for inspecting buildings for accessibility violations in California is **CASp (Certified Access Specialist)**, issued by the state's Division of the State Architect. A CASp report gives business owners real legal protection, which is what makes it sellable. CASp requires 4 years of qualifying work history. Alicia's City of Oakland work (2019–2023) may meet it, which would put the **Feb 5 & 8, 2027** exam in reach and CASp revenue **before the Jun 30, 2027 goal date**. **Recommendation:** apply for CASp by mid-December. Meanwhile, finish CPACC and take the ICC Accessibility Inspector/Plans Examiner exam, so surveys can start selling in January either way.

---

## 1. The three credentials

| | CPACC (IAAP) | ICC Accessibility Inspector/Plans Examiner | CASp (California) |
|---|---|---|---|
| What it proves | Accessibility knowledge (broad) | You can read and apply the accessibility building code | State-certified to inspect buildings for accessibility |
| Prerequisites | Already in progress | None listed | Qualifying work history (see section 2) |
| Exam | IAAP exam | 80 questions, 2.5 hours, open book | Closed book (60 Q, 90 min) + open book (40 Q, 120 min), same day |
| Cost | _[confirm current IAAP fee]_ | $320 | $500 application + $250 per exam ($500) + $200 certification = **$1,200** |
| When | ~3 weeks (your plan) | Any time; exam purchase valid 365 days | Feb 5 & 8, 2027 (register by Jan 15) · June 25 & 28, 2027 (register by June 1) · Oct 1 & 4, 2027 |
| What you can sell | Credibility for consulting and talks | Accessibility surveys and code reviews (not CASp reports) | CASp inspection reports and certificates |
| Renewal | IAAP rules | ICC rules | Every 3 years; 15 continuing-education hours (5 must be California Building Code updates) |

## 2. CASp eligibility: your best route
DSA places every applicant in one category. Eligibility is decided only when you apply; DSA doesn't pre-screen.

| Category | Requirement | Fit for you |
|---|---|---|
| A | 30 semester units in architecture or a related listed field, plus 2 years of qualifying employment | Unlikely: your degrees are journalism/sociology, MPA, MBA |
| **B** | High school diploma plus **4 years** of qualifying employment (code enforcement agency, licensed architect, interior designer, civil/structural engineer, **licensed general contractor**, or school Project Inspector) | **Best route.** City of Oakland Planning & Building, **2019–2023** (Proactive Rental Inspection Program). If the start and end months add up to 4 full years and DSA counts it as code enforcement agency employment, you may qualify now. |
| C | 3 years of employment assessing facilities for disability access | Possible later, if a paid accessibility-assessment job builds this |
| D | California architect or engineer license | Not available |

**Two things that decide it:**
1. **Exact months.** 2019–2023 is 4 years only if the start and end months line up (for example, Jan 2019 to Jan 2023).
2. **Who employed you.** You were a FUSE Corps Fellow placed with the City. If FUSE was the employer on paper, DSA may or may not count it as employment with a code enforcement agency. Your offer letter or W-2s answer this. The application should describe the inspection program work plainly.

**If you come up short:** employment with a licensed general contractor also counts, as does a part-time role with a city code enforcement or building department (which could also count toward your job-search goal).

**First action:** find your Oakland offer letter or W-2s (exact months, employer of record, title), then apply. Apply by mid-December so the application can be approved before the **Jan 15, 2027** registration deadline for the **Feb 5 & 8, 2027** exam.

## 3. Timeline
| When | Step | Your time |
|---|---|---|
| Oct–Nov 2026 | Finish CPACC | Study in short sessions; the Chief of Staff makes practice quizzes |
| Nov 2026 – Jan 2027 | Study for and pass the ICC Accessibility Inspector/Plans Examiner exam | ~2 hours a day of practice questions |
| Jan 2027 | Start selling accessibility surveys and code reviews under the ICC credential | Revenue starts |
| By mid-Dec 2026 | Apply for CASp, Category B ($500) | 1 day |
| Feb 5 & 8, 2027 | CASp exams if approved in time (register by Jan 15) | 2 exam days |
| Mar–Apr 2027 | Results arrive (6–8 weeks); pay $200; listed as a CASp | **Sell CASp inspections before the Jun 30 goal date** |
| Backup: June 25 & 28, 2027 | CASp exams if February doesn't work (register by June 1) | Revenue ~Aug 2027 |

## 4. How it fits the $50K plan
- **Inside the goal window (to Jun 30, 2027):** accessibility surveys and code reviews under ICC + CPACC, sold to small businesses, hotels, venues and property managers. Price to be set by the CFO from real market rates (not yet researched).
- **CASp inspections:** from about April 2027 if the February exam works; about August 2027 if it slips to June.
- **Why businesses pay for CASp:** if an owner gets a CASp inspection and is later sued, they can request an early evaluation conference and a 90-day stay of court proceedings. Minimum statutory damages drop from $4,000 to $1,000 if violations are fixed within 60 days. Some cities help pay: Long Beach reimburses up to $1,500 toward a CASp inspection.
- **Your edge:** you have filed ADA Title III claims yourself and you live with a disability. You know these barriers firsthand.

## 4b. Pricing research (CFO, Oct 15, 2026)
- **No published Bay Area price lists found.** CASp firms quote per site, so rates aren't posted.
- **Best public signal is what cities pay:** San Francisco's small-business accessibility grant covered up to **$1,000** for an entrance-only CASp inspection and up to **$3,000** for a full inspection of a business. Long Beach reimburses up to **$1,500**. These suggest a small-business range of roughly $1,000–$3,000 per site, but they are grant caps, not market prices.
- **How to get real numbers:** ask 3 CASps from San Francisco's published list for a quote on a sample small storefront. That means emailing people Alicia hasn't approved, so it needs her yes first.
- **Grant status:** the SF grant page says applications closed June 30, 2022. Check whether a newer round exists before using it in a pitch.

Sources: [SF small business accessibility grant](https://sf.gov/apply-small-business-grant-help-you-understand-and-plan-accessibility-improvements) · [SF Certified Access Specialists list (2021)](https://sf.gov/sites/default/files/2022-03/SF%20Certified%20Access%20Specialists_short%20list%202021.pdf) · [Long Beach CASp resources](https://longbeach.gov/lbcd/building/building-accessibility-standards/accessibility-resources-for-long-beach-business-owners/)

## 5. Costs to budget
- ICC exam: $320
- CASp: $1,200 (application, two exams, certification)
- CPACC: _[confirm]_
- Code books and study guides: _[CFO to price]_

## 6. Open questions for Alicia
1. Oakland start and end months, title, and employer of record (City or FUSE Corps). Years given: 2019–2023.
2. Do you want the ICC exam before or after CPACC?

## Sources
- [DSA: CASp Certification (fees, exam dates, renewal)](https://www.dgs.ca.gov/DSA/Certifications/Page-Content/Certified-Access-Specialist-CASp-Certification)
- [DSA: CASp Examination, Certification and Practice Standards Handbook (eligibility categories)](https://www.dgs.ca.gov/-/media/Divisions/DSA/Publications/casp/CASp_Handbook1.pdf)
- [ICC: Accessibility Inspector/Plans Examiner exam ($320)](https://shop.iccsafe.org/accessibility-inspector-plans-examiner.html)
- [ICC: exam content outline, 80 questions, open book](https://www.iccsafe.org/wp-content/uploads/21_content.pdf) *(older code edition; confirm the current code cycle when you buy the exam)*
- [City of Long Beach: CASp benefits and $1,500 reimbursement](https://longbeach.gov/lbcd/building/building-accessibility-standards/accessibility-resources-for-long-beach-business-owners/)

# CFO Interview: Building the Revenue Plan

**Executive summary:** These are the CFO's questions for Alicia. Her answers become the facts behind the revenue plan and decide which CFO skills get built first. Answers already known are filled in; fill in the blanks. The CFO never guesses a number that isn't here.

---

## Already known (confirm or correct)
| Item | Answer on file |
|---|---|
| Goal | $50,000 net, Oct 2026 – Jun 30, 2027 |
| Checkpoints | $16,700 by Dec 31 · $33,300 by Mar 31 · $50,000 by Jun 30 |
| Ops & Patient-Navigation Project | $15,000/project; target 2 |
| Medical Records Command Center | Flat fee per client; target 7 |
| Talks | Target 1 in-person keynote + 3 virtual |
| Brand collaborations | Product/affiliate only for now (Kizik, byACRE, SitnStand) |
| Merch store | Live |
| Alicia's time | Up to 4 hours a day |

---

## Questions

### A. Where you are today
1. **Revenue so far:** how much has The disABLED Company earned since Oct 1, 2026, and from what?
   - Answer (Oct 15, 2026): $0.
2. **Pipeline:** who is closest to paying you (name, offer, dollar amount, next step)?
   - Answer (Oct 15, 2026): Nobody yet.
2b. **Warm list:** who could you call or email this week about a paid project (past colleagues, TMA contacts, healthcare orgs, Oakland/city contacts)?
   - Answer (Oct 15, 2026): Not ready to call anyone yet. The only thing sellable today is merch in the store (https://thedisabledcompany.com/shop/). Two new offers to build: a quick workbook, and a paid talk on AI and healthcare.

### B. Prices
3. **Merch margin (asked Oct 15):** about $12 kept per tee. Tees are not selling at all. ($16,700 from tees alone ≈ 1,392 shirts.)
3a. **Medical Records Command Center:** what is the flat fee per client?
   - Answer (Oct 15, 2026): Never set; Alicia asked the CFO to set it.
   - **CFO set:** $1,500 flat, or 3 payments of $500. Target 7 clients ≈ $10,500.
   - **One sentence:** "I turn your scattered medical records into one organized, easy-to-share health hub (diagnoses, medications, labs, care team and follow-ups in one place) so you walk into every appointment prepared and heard."
4. **Talks:** what are your in-person keynote fee, virtual fee, and nonprofit rate?
   - Answer (Oct 15, 2026): Open to all three formats; no fees set yet.
   - **Approved by Alicia (Oct 15, 2026):** in-person keynote $3,500 + travel · virtual $1,500 · nonprofit/patient group $750. Target 1 in-person + 3 virtual ≈ $8,000.
5. **Merch:** which platform, and roughly how much does it sell per month?
   - Answer (Oct 15, 2026): Store at https://thedisabledcompany.com/shop/ (WordPress, likely WooCommerce). About $12 kept per tee; not selling.

### C. Costs and cash
6. **Monthly business costs:** what do you pay each month (software, Buzzsprout, Canva, website, merch production, ads)?
   - Answer (Oct 15, 2026): CFO found these in email receipts (read only); Alicia confirms.
     | Cost | Amount | Found in |
     |---|---|---|
     | Buzzsprout (podcast hosting) | $36/month | Outlook, invoice 9285872, Sep 22 |
     | Canva Business | $25 (Sep 26 invoice; confirm monthly) | Outlook, invoice 05016-0890837 |
     | Calendly Standard | $12/month | Outlook, receipt 2667-4443, Sep 16 |
     | Claude Pro | $20/month (business use? confirm) | Gmail, receipt 2905-8957-9075, Sep 26 |
     | ZenBusiness | **Payment failed** (Sep 6, 7 and 9 notices); amount unknown | Outlook |
     | Website hosting | Not found; confirm | — |
     | **Known total** | **about $93/month** ($113 with Claude) | |
   - Note: Buzzsprout's two Sep 22 emails are the same invoice number, so it is one $36 charge, not a double charge.
7. **How you get paid:** Stripe, PayPal, invoices, platform payouts? Into which business account (name only, no numbers)?
   - Answer (Oct 15, 2026): CFO to find from email (read only); Alicia confirms.

### D. Your limits
8. **What won't you do,** even for good money (travel, certain clients, certain offers)?
   - Answer (Oct 15, 2026): Nothing off the table. Bring every good offer (still within 4 hours a day).
9. **Ad budget:** the most you're willing to spend per month on boosts or ads?
   - Answer (Oct 15, 2026): Up to $100/month.

### E. How you want the CFO to work
10. **Where should the ledger live:** a Google Sheet you can open anytime, or a file in this project?
    - Answer (Oct 15, 2026): A file in this project (`revenue/ledger.csv`).
11. **Check-ins:** Friday numbers only, or also a monthly deep dive?
    - Answer (Oct 15, 2026): Friday numbers + a monthly deep dive.
12. **The bigger goal:** should the plan also track progress toward your $222K personal income target, or only the $50K business goal for now?
    - Answer (Oct 15, 2026): $50K business goal only.

---

## Skills this interview decides
| Candidate skill | One job | Needs answers |
|---|---|---|
| `revenue-plan` | Which offers, how many, by which checkpoint | 1–5, 8 |
| `pipeline-forecast` | Every prospect, its value, odds and next step | 2 |
| `pricing-check` | Price any offer, with the math | 3–5, 6 |
| `worth-it-test` | Dollars per hour of your time for any opportunity | 3–5, 8 |
| `monthly-pnl` | Money in, money out, profit, each month | 6, 7 |

**Recommended first skill: `revenue-plan`.** Everything else plugs into it.

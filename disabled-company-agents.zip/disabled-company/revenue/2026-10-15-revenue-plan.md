# Revenue Plan: $50K by Jun 30, 2027

**Executive summary:** The plan reaches about $51,500 gross from six offers. After about $1,900 in costs and ads, it nets about **$49,600**, roughly $400 short of $50,000; one accessibility survey closes the gap. Two-thirds of the money comes from organizations: two $15,000 Ops & Patient-Navigation Projects. Merch is under 1% of the plan. **Honest read on Dec 31:** even a strong stretch reaches about $12,900, short of the $16,700 checkpoint. The plan catches up by Mar 31. All figures come from the CFO interview (`revenue/cfo-interview.md`), calculated in code on Oct 15, 2026.

---

## 1. The offers that get to $50K
| Offer | Price | How many | Total |
|---|---|---|---|
| Ops & Patient-Navigation Project | $15,000 | 2 | $30,000 |
| Medical Records Command Center | $1,500 | 7 | $10,500 |
| In-person keynote | $3,500 + travel | 1 | $3,500 |
| Virtual talk | $1,500 | 3 | $4,500 |
| *Be Heard* workbook | $27 | 100 | $2,700 |
| Merch (about $12 kept per tee) | $12 | 25 | $300 |
| **Gross** | | | **$51,500** |
| Costs (about $113/month × 9) | | | −$1,017 |
| Ads (up to $100/month × 9) | | | −$900 |
| **Net** | | | **about $49,583** |

**Gap closers:** accessibility surveys (ICC credential, from about January) and CASp inspections (from about April if the February exam works). One survey covers the $417 gap.

## 2. Checkpoints
| By | Target | Realistic stretch | What makes it |
|---|---|---|---|
| Dec 31, 2026 | $16,700 | about $12,900 | One Ops project signed with a 50% deposit ($7,500), 2 Records clients ($3,000), 1 virtual talk ($1,500), 30 workbooks ($810), 10 tees ($120) |
| Mar 31, 2027 | $33,300 | on track if the second Ops project signs by February | Second Ops deposit, Records clients 3–5, workbook steady, first surveys |
| Jun 30, 2027 | $50,000 | | Final Ops payments, keynote, talks, surveys and CASp |

**Rule:** every Ops project takes a 50% deposit at signing. That's what makes the December number possible.

## 3. Where the first money comes from (no cold calls)
1. **Workbook launch** (November): sells while you rest. Head of Marketing posts it; email list buyers get the Records Command Center offer.
2. **Records Command Center:** offered on the last workbook page, on the website, and in posts. Each client is $1,500.
3. **AI & healthcare talk:** Friday post plus the updated speaking page. Patient groups and conferences book 1–3 months out, so ask now.
4. **Ops & Patient-Navigation Projects:** the biggest dollars. The first step is a list of 10 healthcare organizations to approach by email, drafted for your yes, when you're ready.

## 4. Costs found in email (Oct 15, 2026)
| Cost | Per month |
|---|---|
| Buzzsprout | $36 |
| Canva Business | $25 (confirm monthly) |
| Calendly | $12 |
| Claude Pro | $20 (if business) |
| ZenBusiness | Payment failed Sept 6–9; amount unknown. **Fix now.** |
| Website hosting / GoDaddy email | Not found in receipts; confirm |

## 5. CFO rhythm
- **Fridays:** `revenue-check` report (on track or behind, and by how much, plus the one move).
- **Monthly:** a deep dive on this plan: what's working, what to cut, what to push.

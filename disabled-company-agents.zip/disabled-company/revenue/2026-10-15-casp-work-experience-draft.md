# CASp Application: Work Experience Description (DRAFT)

**Executive summary:** This is a draft of the work-experience section for Alicia's CASp application under Category B (high school diploma or GED plus 4 years of qualifying employment, such as with a code enforcement agency). It uses only facts on file. Every [bracket] must be filled from her offer letter, W-2s or records before it goes to DSA. Nothing here should be added or rounded up: DSA decides eligibility from what the application shows, and accuracy is what gets it approved.

---

## What to pull first
1. Offer letter or contract: exact start date, end date, title, and employer of record (City of Oakland or FUSE Corps).
2. W-2s for 2019–2023: who paid you each year.
3. Supervisor's name and title at Planning & Building (DSA may ask for verification).
4. Any document describing the Proactive Rental Inspection Program and your role in it.

## Draft: employment entry

**Employer:** [City of Oakland, Planning & Building Department / FUSE Corps, placed with the City of Oakland Planning & Building Department]
**Title:** Advisor and Lead Project Planner [confirm exact title]
**Dates:** [Month 2019] to [Month 2023]
**Hours:** [Full-time / part-time, hours per week]
**Supervisor:** [Name, title, phone or email]

**Description of duties:**
As Advisor and Lead Project Planner in the City of Oakland's Planning & Building Department, I worked on the Proactive Rental Inspection Program, the City's program for [describe in your own words: e.g., inspecting rental properties for code compliance]. My responsibilities included:
- [Your specific duties in the inspection program, e.g., planning inspection processes, working with code enforcement inspectors, reviewing inspection findings]
- [Any direct involvement with building inspections, code compliance or accessibility]
- [Coordination with code enforcement staff, property owners or tenants]
- Wrote the department's first Racial Equity Assessment.

**How this meets Category B:** The Planning & Building Department [is / includes] the City's code enforcement agency. My role supported its inspection and code compliance work for [number] years [and number] months.

## Notes before submitting
- Describe what you actually did, in plain words. DSA reads for code enforcement work, so name inspection and code compliance duties specifically if you had them.
- If FUSE Corps was the employer on paper, say so plainly and explain the City placement. Don't present it as City employment.
- If the months fall short of 4 full years, don't stretch them. The backup is the June 2027 exam, after adding qualifying time.
- Keep copies of everything you submit.

Apply here: https://www.dgs.ca.gov/DSA/Certifications/Page-Content/Certified-Access-Specialist-CASp-Certification

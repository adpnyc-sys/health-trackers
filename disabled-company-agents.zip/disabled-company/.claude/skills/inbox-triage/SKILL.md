---
name: inbox-triage
description: Sort Alicia's email inboxes (Gmail and Outlook) into what needs her today, what needs a reply, what to read later, and what to ignore, then draft the replies. Use whenever Alicia says "check my email", "sort my inbox", "what came in", "triage", "anything urgent", or when the Chief of Staff builds the daily brief or Day List, even if she doesn't say "triage".
---

# Inbox Triage

Sort every inbox, draft the replies, and hand Alicia a short list of what needs her. Read and draft only.

## Inboxes
- Gmail: adpnyc@gmail.com
- Outlook: _[confirm which account]_
- alicia@thedisabledcompany.com: _[confirm: Gmail, Outlook, or other]_

## Workflow
1. **Search each inbox** for unread and recent mail since the last triage (default: last 24 hours; Mondays: since Friday).
2. **Sort every email into one pile:**
   | Pile | What goes in it | Day List color |
   |---|---|---|
   | **Act today** | Money (payments, invoices, sales); deadlines within 3 days; TMA board; brand, sponsor or client replies; medical appointments and anything from her care team | [RED] if deadline, else [GREEN] |
   | **Reply** | A real person is waiting on an answer, but not today-urgent | [BLUE] |
   | **Read later** | Useful but no action: industry news, TMA updates, research | [GRAY] |
   | **Ignore** | Promotions, newsletters she didn't ask for, automated notices with no action | Not shown |
3. **Draft a reply** for every Act-today and Reply email that needs one. Follow CLAUDE.md: under 150 words, one clear ask, full contact block. Save drafts; never send.
4. **Route** what other skills need:
   - Payments, sales, payouts, invoices → `revenue-check`
   - Brand, sponsor, speaking or client threads with no answer for 7+ days → `follow-up-tracker`
   - Meeting requests → the Chief of Staff's daily brief, with suggested times inside Alicia's 4 hours
5. **Build the output** below.

## Output
For the Day List artifact (clickable, color-coded, side panel):
```
INBOX — [date] · [X] emails sorted · [X] need you

ACT TODAY
[ ] [label] [Sender] — [one-line what and why] — [draft ready / no reply needed] — [est. minutes]

REPLY (drafts ready for your yes)
[ ] [Sender] — [one line]

READ LATER ([count])
- [Sender] — [one line]

ROUTED
- To revenue-check: [count]
- To follow-up-tracker: [count]
- Ignored: [count]
```

## Rules
- **Read and draft only.** Don't send, label, archive, move, delete or mark as read. Alicia sees her inbox exactly as she left it.
- **Never guess importance from the sender name alone.** Read enough of the email to know what it asks.
- **One line per email.** Alicia reads the line, not the email.
- **Act today stays short.** If it's longer than 7 items, move the lowest to Reply and say so.
- Personal medical emails: list them in Act today by sender and "appointment" or "message from care team" only. Don't summarize medical details.
- Anything that looks like a scam, phishing or a payment request from an unknown sender: flag it [RED] with "Possible scam — don't click," and draft nothing.

## Open questions for Alicia (answer to sharpen this skill)
1. Which Outlook account, and where does alicia@thedisabledcompany.com live?
2. Anything else that's always Act today?
3. Senders or types to always ignore?
4. What do you redo by hand every time you sort email?
5. What has gone wrong before?

---
name: revenue-check
description: Log every dollar The disABLED Company earns and report whether Alicia is on track for $50K by Jun 30, 2027. Use every Friday, and whenever Alicia asks "am I on track?", "how much have I made?", "how's revenue?", "log this sale", or mentions a payment, invoice, payout or commission, even if she doesn't say "revenue".
---

# Revenue Check

Answer one question: **Is Alicia on track for $50K by Jun 30, 2027?** Give a clear yes or no, the dollar gap, and the one move that closes it fastest. Used by the Chief of Staff (Friday numbers) and the CFO (planning).

## Workflow
1. **Open the ledger:** `revenue/ledger.csv`. Create it if missing, with these columns:
   `date,source,stream,description,gross,fees,net,status,proof`
   - `stream`: Ops Project, Records Command Center, Speaking, Merch, Brand Collab, Affiliate, Research Commission, Sponsorship, Membership, Other
   - `status`: Paid or Pending
   - `proof`: email subject, order number or invoice number
2. **Collect new money** since the last check:
   - Emails routed from `inbox-triage`
   - Gmail + Outlook search, last 7 days: orders, payouts, commissions, paid invoices, Stripe, PayPal, and the platforms in `context/company-facts.md`
   - Anything Alicia says directly ("I got $300 from X")
3. **Log each one** as a row. Check `proof` first so nothing is counted twice.
4. **Do the math:**
   - Weekly target: $1,300
   - Checkpoints: $16,700 by Dec 31, 2026 · $33,300 by Mar 31, 2027 · $50,000 by Jun 30, 2027
   - Pace needed = (next checkpoint − net to date) ÷ weeks left to that checkpoint
   - Pipeline (signed, not paid) is listed separately and does not count until paid.
5. **Pick the ONE MOVE:** the single action with the biggest dollar impact this week, usually a follow-up, an invoice to send, or a proposal to close.
6. **Save and show** the report below.

## Output: save to `reports/YYYY-MM-DD-revenue-check.md`
```
REVENUE CHECK — [date]
Status: ON TRACK / BEHIND by $X / AHEAD by $X
This week: $X net (target $1,300)
To date: $X of $50,000 (X%)
Next checkpoint: $16,700 by Dec 31 → need $X/week from here

By stream (to date):
- [each stream with revenue]: $X

Pipeline (signed, not paid): $X — [who]
Needs Alicia: [pending items with no amount, or "none"]

ONE MOVE THIS WEEK: [action] — [dollar impact]
```
No essay, no pep talk: the numbers and the move.

## Rules
- **Never guess an amount.** No clear dollar figure → log as Pending with net blank, and list it under "Needs Alicia".
- **Net counts** toward the goal (after platform fees).
- **disABLED Company only.** Exclude KREATE Advisors and job income.
- **Read only.** Don't send, reply to, label or move any email.
- Run the arithmetic in code, not in your head, and show the figures it produced.

# Be Heard: The Patient's Workbook for Doctor Visits, Records and Pushback
### Fill-in-the-blank tools for people living with a rare or chronic condition
*By Alicia D. Polak · The disABLED Company™*

> **DRAFT v1 (Oct 15, 2026), for Alicia's review.** Text only; design happens in Canva. [Brackets] are notes for Alicia. Pages from her earlier ChatGPT workbook get merged in once she shares that file.

---

## Page 1: Start Here

I live with Inclusion Body Myositis. I've sat in exam rooms where I wasn't heard, chased records across three offices, and fought denials I knew were wrong. This workbook is what I wish someone had handed me on day one.

**How to use it**
1. Fill in **My Health at a Glance** once. Update it when anything changes.
2. Use **Before, In and After the Visit** for every appointment.
3. Use **My Records Command Center** to get and keep your records.
4. Use **When the Answer Is No** the moment you get a denial.

You don't have to do it all today. One page is progress.

*This workbook is for organizing and advocating for your own care. It is not medical advice. Your clinicians make medical decisions with you.*

[Alicia: add one line in your own voice here, e.g., your mantra.]

---

## Pages 2–3: My Health at a Glance

**Me**
- Name: ____________________ Date of birth: ____________
- Diagnoses (and year diagnosed): ______________________________
- Allergies and reactions: ______________________________
- Emergency contact (name, relationship, phone): ______________________________

**My medications**
| Medication | Dose | How often | Prescribed by | Started |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |

**My care team**
| Role (e.g., neurologist, PCP, PT) | Name | Phone | Portal or email | Next visit |
|---|---|---|---|---|
| | | | | |
| | | | | |

**What every new clinician should know about me in 30 seconds**
______________________________________________________________
______________________________________________________________

---

## Pages 4–6: Before the Visit

**Visit:** ______________ **Date:** ______ **With:** ______________

**My top 3 questions** (most important first)
1. ______________________________
2. ______________________________
3. ______________________________

**What's changed since my last visit**
| What | When it started | Better / worse / same |
|---|---|---|
| | | |
| | | |

**Symptom log (1 week)**
| Day | Energy (1–5) | Pain (1–5) | What I could and couldn't do |
|---|---|---|---|
| Mon | | | |
| Tue | | | |
| Wed | | | |
| Thu | | | |
| Fri | | | |
| Sat | | | |
| Sun | | | |

**What I need from today** (one sentence): ______________________________

**Bring:** this workbook · medication list · insurance card · someone to take notes, if possible

---

## Pages 7–8: In the Room

**Scripts that work**
- **If you're talked over:** "I'd like to finish my point. It matters for my care."
- **If it's all jargon:** "Can you say that in plain language? I want to make sure I understand."
- **If you're rushed:** "I have three questions. Can we get through all three, or schedule time for the rest?"
- **If a request is refused:** "Can you note in my chart that I asked for this and why it was declined?"
- **If you need it in writing:** "Please put that in my visit summary so I can refer back to it."

**The No Thank You™ moment**
Sometimes reasoning doesn't work. When someone dismisses you or blocks you, a calm, clear "No, thank you" stops it. Then say what you need instead.

My No Thank You™ line: ______________________________

[Alicia: add one real moment from your own visits here.]

---

## Pages 9–10: After the Visit

**Visit summary**
- What the clinician said is going on: ______________________________
- What we decided: ______________________________
- Tests or referrals ordered: ______________________________
- Medication changes: ______________________________

**Follow-up tracker**
| To do | Who | By when | Done |
|---|---|---|---|
| | | | ☐ |
| | | | ☐ |
| | | | ☐ |

**Did I get my 3 questions answered?** ☐ Yes ☐ Partly ☐ No → next step: ______________

---

## Pages 11–14: My Records Command Center

**Why it matters:** your records are your story. When they're in one place, every new clinician starts from the facts, not from scratch.

**How to request your records**
1. Ask each office or hospital for its records request form, or use the patient portal.
2. Ask for visit notes, test and lab results, imaging reports, and medication history.
3. Ask for digital copies when possible.
4. Write down when you asked and when they say it will arrive.

You have a legal right to access your own health records under HIPAA. For details, see the U.S. Department of Health and Human Services: https://www.hhs.gov/hipaa/for-individuals/right-to-access/index.html

**Records request tracker**
| Office | What I asked for | Date asked | Promised by | Received |
|---|---|---|---|---|
| | | | | ☐ |
| | | | | ☐ |
| | | | | ☐ |

**My simple filing system** (paper or digital folders)
1. Summary (My Health at a Glance)
2. Visit notes (newest first)
3. Labs and tests
4. Imaging
5. Medications
6. Insurance and billing

---

## Pages 15–17: When the Answer Is No

**Denial tracker**
| What was denied | Date | Reason given | Appeal deadline | Status |
|---|---|---|---|---|
| | | | | |
| | | | | |

**Appeal checklist**
- ☐ Get the denial in writing
- ☐ Find the appeal deadline and mark it on your calendar
- ☐ Ask your clinician for a letter of medical necessity
- ☐ Gather supporting records (see your Command Center)
- ☐ Submit the appeal, and keep a copy of everything
- ☐ Write down every call: date, name, what they said

**Call log script**
"Hi, I'm calling about a denial for [service] on [date]. Can I get your name and a reference number for this call? What exactly do you need from me to reverse this decision, and by when?"

| Date | Who I spoke with | Reference # | What they said |
|---|---|---|---|
| | | | |

---

## Page 18: My People

| For this... | I call... | Phone |
|---|---|---|
| Medical emergency | 911 | |
| Urgent questions | | |
| Rides to appointments | | |
| Someone to take notes | | |
| Insurance help | | |
| Emotional support | | |
| Patient organization (e.g., The Myositis Association, https://www.myositis.org) | | |

---

## Page 19: Your Next Step

You've done the hard part: you're organized, prepared, and ready to be heard.

**Want it done for you?** The **Medical Records Command Center** turns your scattered medical records into one organized, easy-to-share health hub, so you walk into every appointment prepared and heard. $1,500, or 3 payments of $500.

**Stay connected:** join the newsletter at https://www.thedisabledcompany.com

*Not medical advice. Always make medical decisions with your care team.*

Alicia D. Polak · Chief Enabled Officer · The disABLED Company™
alicia@thedisabledcompany.com · https://www.thedisabledcompany.com

# Quick Workbook: Outline (DRAFT for Alicia's yes)

**Executive summary:** A short, fillable PDF workbook that sells on thedisabledcompany.com as an instant download. Recommended topic: **getting heard in healthcare** (doctor visits, medical records, and pushing back on denials), because it draws on work Alicia has already done and leads naturally to her paid Medical Records Command Center. Recommended price: **$27**. Target build time for Alicia: about 4 hours of review; the Chief of Staff drafts everything. This is separate from the companion workbook for her book.

---

## Note: Alicia already started a workbook
- Alicia started a companion workbook to her book in ChatGPT: black and gold to match the book cover, with an "Exercises" section (safety rules, choosing a level, logging fatigue, pain and recovery, when to call your clinician, and a bridge page to the ABLED ACTION DECK™). Source: `chatgpt-import/book-and-workbook.md` in this Claude project.
- The workbook file itself never came over from ChatGPT. It is not in this project or in Google Drive.
- **To do:** Alicia exports the workbook from ChatGPT and drops it here. Then we reuse its design (black and gold) and any pages that fit *Be Heard*, and keep the Exercises section for the book's companion workbook.

## Recommended pick
**Title:** *Be Heard: The Patient's Workbook for Doctor Visits, Records and Pushback*
**Subtitle:** Fill-in-the-blank tools for people living with a rare or chronic condition

**Why this one:**
1. It builds on what already exists: the "How to Communicate With Your Doctor" podcast episode and cheat sheet, and the No Thank You™ idea.
2. It's the do-it-yourself version of the Medical Records Command Center, so every buyer is a lead for the paid service.
3. It serves exactly who you serve: people with IBM and other rare conditions who are tired of not being heard.

**Alternative (only if you prefer):** a workbook on accessible travel: planning, packing, airport and hotel scripts.

## Chapters (about 20–25 pages)
1. **Start here** (1 page): how to use the workbook; "not medical advice" disclaimer.
2. **My health at a glance** (2 pages): fill-in: diagnoses, medications, care team, allergies, emergency contacts.
3. **Before the visit** (3 pages): top-3-questions worksheet, symptom log, "what I need from today" line.
4. **In the room** (2 pages): scripts for being talked over, asking for plain language, asking for it in writing. Includes No Thank You™.
5. **After the visit** (2 pages): visit summary, follow-up tracker, "what changed" log.
6. **Your records command center** (4 pages): how to request your records, what to keep, a simple filing system, a records-request tracker.
7. **When the answer is no** (3 pages): insurance denial tracker, appeal checklist, script for calling insurance.
8. **Your people** (1 page): who to call for what.
9. **Next step** (1 page): an invitation to the Medical Records Command Center (done-for-you service, $1,500) and the newsletter.

## Format and sales
- Fillable PDF, designed in Canva, in brand colors.
- Sold as a digital download in the WooCommerce store; no shipping, no inventory.
- Price: **$27**. Low enough to buy without thinking, high enough to signal value.
- Email capture: every buyer joins the newsletter.

## Revenue math (CFO)
- At $27 per copy, roughly $27 kept per sale before payment fees (no printing cost).
- 100 copies ≈ $2,700. Compare tees: 100 tees at about $12 ≈ $1,200.
- Its bigger job: each buyer is a warm lead for the Medical Records Command Center.

## Build plan
| Step | Who | Time for Alicia |
|---|---|---|
| Draft all pages and worksheets | Chief of Staff | 0 |
| Fact-check health content | Medical Research Lead | 0 |
| Review and approve content | Alicia | ~2 hours |
| Canva design | Chief of Staff / Head of Marketing | 0 |
| Review design and approve | Alicia | ~1 hour |
| Set up product in the store | Alicia (with step-by-step SOP) | ~1 hour |
| Launch posts | Head of Marketing | 15-minute review |

## Needs Alicia's yes
1. Topic: *Be Heard* (recommended) or accessible travel.
2. Price: $27.

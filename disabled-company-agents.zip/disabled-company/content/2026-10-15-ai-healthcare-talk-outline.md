# Paid Talk: AI and Healthcare (DRAFT outline + speaker sheet)

**Executive summary:** A 45-minute talk, also offered as a 60-minute workshop, on how patients can use AI to organize their care and get heard, told from Alicia's experience living with IBM and building her own AI-organized medical hub. It sells to patient organizations, hospital patient-experience teams, disability and rare-disease conferences, and employer disability groups. The fee is set after the CFO interview (question 4).

---

## Title options (one pick first)
1. **Recommended:** *AI in Your Corner: How Patients Use AI to Organize Their Care and Get Heard*
2. *From Overwhelmed to Organized: AI for People Living With Chronic and Rare Conditions*

## Who buys it
1. Patient advocacy groups and rare-disease organizations (conferences, webinars, support-group series)
2. Hospital and health-system patient-experience and patient-family advisory teams
3. Disability inclusion programs and employee resource groups at companies
4. Healthcare and digital-health conferences (patient-voice sessions)

## 3 takeaways for the audience
1. **Organize:** how to use AI to turn scattered records, labs and visit notes into one clear summary.
2. **Prepare:** how to use AI to get ready for appointments: questions, timelines, what changed.
3. **Stay safe:** what never to trust AI with, how to protect your privacy, and why your clinician makes the medical calls.

## Talk structure (45 minutes)
| Time | Section |
|---|---|
| 0–5 | Opening: Alicia's story (hiker and half-marathoner → IBM diagnosis → refusing to let an "ITIS" define her) |
| 5–15 | The problem: records everywhere, rushed visits, patients not heard |
| 15–30 | Live walkthrough: how Alicia organizes her own care with AI (shown with sample, not real, data) |
| 30–38 | Guardrails: privacy, accuracy, what AI can't do |
| 38–45 | Q&A and next steps: workbook, Medical Records Command Center |

**Workshop version (60 min):** adds 15 minutes where attendees build their own one-page health summary with a template.

## Speaker sheet (one page, for Canva)
```
AI IN YOUR CORNER
How Patients Use AI to Organize Their Care and Get Heard

Alicia D. Polak
Chief Enabled Officer, The disABLED Company
Board Member, The Myositis Association

[Photo or brand graphic]

Alicia lives with Inclusion Body Myositis and uses AI to run her own care.
A former BlackRock and Merrill Lynch VP, social entrepreneur, Wharton lecturer
and TEDxPretoria speaker, she shows patients how to use AI to stay organized,
prepared and heard, safely.

Audiences leave with:
1. A simple way to organize records with AI
2. A prep routine for every appointment
3. Clear guardrails for privacy and accuracy

Formats: 45-minute keynote · 60-minute workshop · virtual or in person
Fees: in person $3,500 + travel · virtual $1,500 · nonprofit rates available

Book Alicia: alicia@thedisabledcompany.com · 856-278-1466
https://www.thedisabledcompany.com/speaking/
```

## Rules for this talk
- Use sample data in demos, never Alicia's real records on screen.
- "Not medical advice" on the final slide.
- Medical Research Lead fact-checks any claim about AI accuracy or research.

## Needs Alicia's yes
1. Title.
2. Whether to show fees on the speaker sheet, or share them only on request (approved fees: $3,500 in person + travel, $1,500 virtual, $750 nonprofit).
3. Whether the speaker sheet goes on the /speaking/ page.

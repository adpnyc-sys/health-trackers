# Chief of Staff: Skill Plan

**Executive summary:** The Chief of Staff is the first agent for The disABLED Company. Its job is to carry the weight of running the week so Alicia spends her 4 hours a day on revenue work and decisions, not sorting and remembering. It runs on four skills, one job each. It reads and drafts only; nothing is sent, moved or deleted without Alicia's yes. **Build Inbox Triage first.** It runs every day, so it gets the most practice and feedback, and it feeds the other three skills: revenue emails go to Revenue Check, and stalled threads go to Follow-Up Tracker.

---

## 1. Interview results (Oct 15, 2026)

### Context
- Business: The disABLED Company, run by Alicia alone. Rules live in `CLAUDE.md` (the employee handbook).
- Goal: $50K net revenue by Jun 30, 2027. Checkpoint: $16,700 by Dec 31, 2026.
- Tools: Gmail, Outlook, Google Calendar, Asana, Canva, Google Drive, Notion.

### What drains Alicia's energy (all four, her answer)
1. Sorting her inboxes
2. Planning her week
3. Follow-ups slipping
4. Not knowing her revenue number

### Constraints
- Alicia: up to 4 hours a day. She tires easily. Plan around energy.
- **The Chief of Staff:** works as hard as needed, up to 15 hours a day. Its effort is not limited by Alicia's energy. The heavy lifting is its job, not hers.
- **Authority: read and draft only.** It can read email, calendar, Asana and Drive. It drafts replies, plans and task lists. It does not send, label, archive, move, delete, schedule or create anything without Alicia's yes.

### Rhythm
- **Daily brief** (each work day)
- **Sunday plan** (the week)

### Definition of done
- The Chief of Staff does the hard, tedious work. Alicia only reviews, decides and approves.
- Each brief is ready to act on: no extra digging, no "let me check."
- Nothing is sent or changed without her yes.

---

## 2. Skill roster (one skill, one job)

Your four drains are four separate jobs, so they become four skills. The Chief of Staff agent runs them and stitches the results into the daily brief and the Sunday plan.

| # | Skill folder | One job | Runs | Feeds |
|---|---|---|---|---|
| 1 | `inbox-triage` | Sort Gmail + Outlook into Act / Reply / Read / Ignore. Draft replies for the Reply pile. | Daily | Daily brief, skills 3 and 4 |
| 2 | `week-plan` | Plan the week at 4 hours a day for Alicia, revenue first | Sunday | Sunday plan |
| 3 | `follow-up-tracker` | Track every open thread with a brand, sponsor or lead. Flag what's due. Draft the nudge. | Daily | Daily brief, week-plan |
| 4 | `revenue-check` | Log every dollar in. Report actual vs. $1,300/week and the next checkpoint. | Friday + on demand | Sunday plan |

**Not a skill:** the daily brief and the Sunday plan. Those are the Chief of Staff's own job description. It runs the skills, then writes the brief.

**Status (Oct 15):** `inbox-triage` and `revenue-check` are built (`revenue-check` replaced the old revenue-tracker agent). `week-planner` stays an agent under the Chief of Staff. `follow-up-tracker` is next.

---

## 3. Where to start: Inbox Triage

**Why first:**
1. **It runs daily.** More practice means faster improvement. A weekly skill takes 4 weeks to get 4 rounds of feedback. A daily skill gets 4 rounds in 4 days.
2. **It feeds everything else.** Payout and sale emails go to Revenue Check. Quiet brand and sponsor threads go to Follow-Up Tracker. Meeting requests go to Week Plan.
3. **It fits "read and draft only."** It reads, sorts and drafts. Nothing leaves without Alicia.
4. **It's the morning brief's backbone.** The daily brief is mostly inbox triage plus today's calendar.

**Build order:**
1. `inbox-triage`
2. `follow-up-tracker`
3. `revenue-check`
4. `week-plan`

---

## 4. Interview questions for building Inbox Triage
Answer these next, and the SKILL.md gets written from your answers.
1. Which email accounts, by name? (Gmail: adpnyc@gmail.com; Outlook: which one; alicia@thedisabledcompany.com?)
2. What counts as **Act today** for you? Examples: money, deadlines, TMA board, doctors, brand replies.
3. What should it **always ignore**? Newsletters, promotions, specific senders?
4. What have you redone by hand every time you triaged in the past?
5. What has gone wrong before? Missed emails, wrong priority, drafts that didn't sound like you?
6. Output: the clickable color-coded Day List in the side panel. Confirm that's still the format.

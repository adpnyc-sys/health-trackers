# Website Page: Medical Records Command Center (DRAFT)

**Executive summary:** A new page for thedisabledcompany.com that sells the Medical Records Command Center at $1,500, or 3 payments of $500. Copy is first person and present tense, ready to paste into Divi. Suggested URL: thedisabledcompany.com/records-command-center/

---

## Hero
**H1:** Your Medical Records Command Center
**Subheading:** I turn your scattered medical records into one organized, easy-to-share health hub, so you walk into every appointment prepared and heard.
**Button:** Book a free 15-minute call → (Calendly link)

## The problem (H2: Sound familiar?)
- Your records live in five portals and three filing cabinets.
- Every new doctor asks you to start from scratch.
- You leave appointments thinking, "I forgot to mention…"

I've been there. I live with Inclusion Body Myositis, and I built my own command center so I'd never walk in unprepared again. Now I build one for you.

## What you get (H2: What's included)
1. **One health summary:** diagnoses, medications, allergies, care team, and history on one page you can hand to any clinician.
2. **Organized records:** visit notes, labs, imaging and medication history, sorted and easy to find.
3. **A timeline:** what happened, when, and what changed.
4. **A follow-up list:** open referrals, tests and questions, so nothing slips.
5. **A walkthrough call:** I show you how to use it and keep it current.

## How it works (H2: How it works)
1. **Free 15-minute call.** We make sure it's a fit.
2. **You gather, I guide.** I give you a simple checklist for requesting your records.
3. **I build it.** Usually within [X] weeks of receiving your records. [Alicia: set the turnaround.]
4. **We walk through it together.**

## Price (H2: Investment)
**$1,500**, or **3 payments of $500**.

Want to start on your own first? Get the *Be Heard* workbook for $27. [link when live]

## Trust and privacy (H2: Your privacy)
- Your records are used only to build your command center.
- I share them with no one.
- [Alicia: add how records are stored and deleted. Confirm this with the CFO and any legal advice before the page goes live.]

## Disclaimer
I'm not a doctor, and this isn't medical advice. I organize your information so you and your care team can make decisions together.

## Final call to action
**H2:** Walk into your next appointment ready.
**Button:** Book a free 15-minute call →
Or email alicia@thedisabledcompany.com

---

## Before it goes live
1. Set the turnaround time.
2. Write the privacy section: how records are sent, stored and deleted.
3. Add the Calendly link (you already pay for Calendly).
4. Brand Guardian check.

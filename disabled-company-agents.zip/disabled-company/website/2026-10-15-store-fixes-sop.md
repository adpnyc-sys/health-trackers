# SOP: Fix the Store's Duplicate Listings and Broken Links

**Executive summary:** Three quick fixes on thedisabledcompany.com that make the store look finished and trustworthy: remove duplicate product listings, fix the Facebook links, and rename the menu item. About 30–45 minutes in WordPress. The site runs on WordPress with the Divi theme, and the store appears to be WooCommerce; menu names below may differ slightly.

---

## What's wrong (found Oct 15, 2026)
| Problem | Where | Fix |
|---|---|---|
| Each tee, polo and cap is listed 3 times | Shop page | Keep one listing per product, with colors as options |
| Footer Facebook goes to facebook.com/aliciapolakcoaching | Footer | Change to https://www.facebook.com/thedisabledcompany |
| Header Facebook icon goes nowhere ("#") | Header | Same link as above |
| Menu says "Shopping Cart" | Main menu | Rename to "Shop" |

## Fix 1: Duplicate listings (about 20 minutes)
1. Log in to WordPress: https://thedisabledcompany.com/wp-admin
2. Go to **Products → All Products**.
3. Open each of the 3 tee listings. Note what's different (usually color).
4. **If your print company syncs products** (Printful, Printify): fix it there first, by combining the colors into one product, then re-sync. Otherwise the duplicates come back.
5. **If not synced:** keep the best listing and add the other colors as options under **Product data → Attributes** (color), then **Variations**.
6. Move the extra listings to **Trash** (recoverable for 30 days).
7. Repeat for the polo and the cap.
8. Check https://thedisabledcompany.com/shop/: one tee, one polo, one cap.

## Fix 2: Facebook links (about 10 minutes)
1. **Header icon:** go to **Divi → Theme Options → General**, find **Facebook Profile URL**, and paste https://www.facebook.com/thedisabledcompany. Save.
2. **Footer link:** go to **Divi → Theme Builder**, open the footer template, click the Facebook icon or link, and paste the same URL. Save.
   - If there's no custom footer, look in **Appearance → Widgets** or **Appearance → Customize → Footer**.
3. Open the site in a private browser window and click both Facebook icons to test.

## Fix 3: Rename the menu item (about 5 minutes)
1. Go to **Appearance → Menus**.
2. Open the "Shopping Cart" item, change **Navigation Label** to **Shop**, and save the menu.

## Done when
- Shop page shows each product once.
- Both Facebook icons open The disABLED Company page.
- The menu says "Shop."

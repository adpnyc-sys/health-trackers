# Speaking Page Update: thedisabledcompany.com/speaking/ (DRAFT)

**Executive summary:** The current Speaking page has no talk titles, no topics, no visible booking email, duplicate headings, and broken menu links. This draft replaces the body copy with one clear offer, the AI & healthcare talk, plus two more talks, and a booking section that shows how to reach Alicia. Fees stay off the page and are shared on request. Copy is first person and present tense, ready to paste into Divi.

---

## Hero
**Heading (H1):** Speaking
**Subheading:** I help audiences get organized, get heard, and get ABLED.

## About (H2: Hi, I'm Alicia)
I'm a former Wall Street banker turned social entrepreneur. I founded the Khayelitsha Cookie Company in South Africa, I've lectured on social entrepreneurship at Wharton, and I spoke at TEDxPretoria. Today I live with Inclusion Body Myositis, a rare, progressive muscle disease, and I run The disABLED Company, where the emphasis is always on ABLED.

My talks are energetic, funny and honest. Audiences leave with tools they use the next day.

## Talks (H2: Talks)

**1. AI in Your Corner: How Patients Use AI to Organize Their Care and Get Heard** (featured)
I show how I use AI to run my own care: turning scattered records into one summary, preparing for every appointment, and knowing where AI should never be trusted.
*Best for:* patient organizations, rare-disease conferences, hospital patient-experience teams, employee disability groups.
*Formats:* 45-minute keynote · 60-minute hands-on workshop · virtual or in person

**2. Profits with a Purpose**
How I went from investment banking to building a social enterprise, and why social impact and profit belong together. Based on my TEDxPretoria talk: https://www.youtube.com/watch?v=IABB4D9-pkw
*Best for:* business schools, social-impact and entrepreneurship audiences.

**3. Be Heard: Advocating for Yourself in Healthcare**
Scripts and tools for doctor visits, records and insurance denials, from someone who uses them every week. Includes the No Thank You™ approach.
*Best for:* patient groups, caregivers, disability and chronic-illness communities.

## Booking (H2: Book Me)
Tell me your event, date, audience and format, and I'll reply within 2 business days.
- Email: alicia@thedisabledcompany.com
- Phone: 856-278-1466
- [Book Now button → mailto:alicia@thedisabledcompany.com?subject=Speaking%20inquiry]

Nonprofit and patient-group rates are available.

---

## Fixes to make while editing (Divi)
1. Delete the duplicate "Hi, I'm Alicia" heading and the repeated "Help Your Audience Transform" section.
2. Show the booking email as plain text so visitors can see it, as well as on the button.
3. Fix the banner image's title text; it's currently garbled.
4. Point the Topics menu items to real pages, or remove them until those pages exist.
5. Header Facebook and YouTube links: match the footer (see `website/2026-10-15-store-fixes-sop.md`).

## Claims check
- "South Africa's longest-running social enterprise" was removed from the page copy until it is sourced.
- "TEDx-proven" was replaced with the factual "I spoke at TEDxPretoria."

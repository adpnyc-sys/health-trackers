# Ops & Patient-Navigation Project: 10 Target Organizations (DRAFT for Alicia's yes)

**Executive summary:** Ten organizations that could buy a $15,000 Ops & Patient-Navigation Project. Five are Bay Area health systems, including the three named in the company's founding concept (Kaiser, Sutter, John Muir). Three are national neuromuscular and rare-disease leaders, and two are mission-aligned organizations. Nobody gets contacted until Alicia says yes, organization by organization. Named contacts come next, from her LinkedIn and email (read only), not guesses. The Myositis Association is left off on purpose because Alicia sits on its board.

**The pitch in one line:** I'm a PMP-certified program manager who lives with a rare neuromuscular disease. I help your team find and fix the points where disabled and rare-disease patients get lost, and deliver a navigation process your staff can run.

---

| # | Organization | Why it fits | Who to approach (role) | Alicia: yes / no |
|---|---|---|---|---|
| 1 | **Kaiser Permanente (Northern California)** | Named in the founding concept as a target for embedded consulting; huge disabled-patient population in your region | Patient experience, care navigation, or accessibility/ADA program leads | |
| 2 | **Sutter Health** | Named in the founding concept; large Bay Area system | Patient experience or patient navigation leaders | |
| 3 | **John Muir Health** | Named in the founding concept; the East Bay system closest to you | Patient experience or community health leaders | |
| 4 | **UCSF Health** | Academic center that treats complex neuromuscular and rare-disease patients | Neuromuscular or rare-disease clinic operations; patient experience | |
| 5 | **Stanford Health Care** | Academic center with complex-care patients who cross many departments | Patient experience; patient and family advisory programs | |
| 6 | **Contra Costa Health** | Your county's public health system; you've done public-sector work in Martinez and Oakland | Patient navigation or disability/ADA access leads | |
| 7 | **Hospital for Special Surgery (HSS)** | Received TMA's 2026 Heroes in Healthcare Award; a major myositis care center | Rheumatology/myositis program operations; patient experience | |
| 8 | **Johns Hopkins Myositis Center** | One of the best-known myositis centers in the U.S.; sees IBM patients from across the country | Center administrator or program manager | |
| 9 | **Muscular Dystrophy Association (MDA)** | Serves the neuromuscular community, including myositis; runs patient programs and webinars | Programs, care-center network, or community engagement leads | |
| 10 | **National Organization for Rare Disorders (NORD)** | National rare-disease umbrella with patient-support programs | Patient services or programs leads | |

**Left off on purpose:** The Myositis Association. You're on its board, so selling it a paid project is a conflict of interest. Keep TMA as advocacy and the MyoCon sponsor introductions.

---

## Next steps after your yes
1. **Find a warm path** for each yes: the Chief of Staff searches your LinkedIn connections and email (read only) for anyone you already know at each organization.
2. **Draft one short email per organization** (under 150 words, one clear ask: a 20-minute call), for your yes before anything is sent.
3. **One-page project overview** to attach: the problem, what you deliver in 8–12 weeks, $15,000 with a 50% deposit.

## Sources
- [TMA: HSS receives TMA's 2026 Heroes in Healthcare Award](https://www.myositis.org/blog/hss-receives-heroes-in-healthcare-award/)
- Founding concept targets (Kaiser, Sutter Health, John Muir): `business/concept-document.md` in this Claude project

# The disABLED Company: Company Facts (context vault)

Reference facts the agents look up. Update the numbers here; the rules live in CLAUDE.md.

## Who we are
- The disABLED Company, LLC. Trademarked name. Run by Alicia D. Polak, Chief Enabled Officer, alone.
- Mission: empowering the disabled community through consulting, advocacy, and proudly branded merchandise.
- Audience: people in the disabled community, especially people living with Inclusion Body Myositis (IBM), who will pay for condensed, high-quality information.
- Alicia is also a Board Member of The Myositis Association (TMA). TMA content is advocacy, not sales.

## Goals (Oct 2026 – Jun 2027)
| Goal | Target |
|---|---|
| Revenue | $50,000 net, about $1,300/week |
| Checkpoint 1 | $16,700 by Dec 31, 2026 |
| Checkpoint 2 | $33,300 by Mar 31, 2027 |
| Checkpoint 3 | $50,000 by Jun 30, 2027 |
| Social | 2 revenue posts/week (Tue/Fri) + 1 TMA post/week |
| Job search | 5 targeted part-time remote applications/week |

## Work capacity
- Alicia: up to 4 hours a day. Week planned on Sundays.
- Chief of Staff: up to 15 hours a day.

## Offers and revenue streams
| Stream | Status | Price / target |
|---|---|---|
| Ops & Patient-Navigation Project (orgs) | Selling | $15,000/project; target 2 |
| Medical Records Command Center (individuals) | Selling | **$1,500 flat** (or 3 payments of $500); target 7 clients ≈ $10,500 (set Oct 15, 2026) |
| Keynote / virtual talks | Selling | 1 in-person + 3 virtual |
| Merch store | **Live: the only offer selling today** | https://thedisabledcompany.com/shop/ (WordPress, likely WooCommerce). Women's organic tee $41.22 · Empowerment polo $56.22 · Dad cap $30 · Dog leash $32 · Biodegradable phone case $26.05–$29.92 |
| Quick workbook (digital) | To build | Price TBD by CFO |
| Paid talk: AI and healthcare | To build | In-person $3,500 + travel · virtual $1,500 · nonprofit $750 (approved Oct 15, 2026) |
| Brand collaborations (Kizik, byACRE, SitnStand) | Pitching | Product/affiliate for now |
| Affiliate links | Building | Networks: _[fill in]_ |
| Paid research recruitment posts | As available | Commission |
| Sponsorships | Pipeline | Invoices |
| Accessibility surveys (ICC + CPACC) | Certification in progress | Start ~Jan 2027; price TBD by CFO |
| CASp inspections | Certification track | Apply by mid-Dec 2026; exam Feb 2027 (backup June); see `revenue/2026-10-15-accessibility-certification-track.md` |
| Membership | Planned | — |

## Alicia's real story (the only version agents may use)
Former hiker and half-marathoner. Diagnosed with IBM, the same disease her mother had. Months in bed at times. Refuses to let an "ITIS" define her. Founded The disABLED Company to put the emphasis on ABLED.

## Approved links
- Website: https://www.thedisabledcompany.com
- Instagram: https://www.instagram.com/aliciathedisabledcompany
- Facebook: https://www.facebook.com/thedisabledcompany
- TEDxPretoria, "Profits with a Purpose": https://www.youtube.com/watch?v=IABB4D9-pkw
- TMA: https://www.myositis.org

## Contact block / signature
```
Alicia D. Polak
Chief Enabled Officer
The disABLED Company
alicia@thedisabledcompany.com · 856-278-1466
https://www.thedisabledcompany.com
```

## Audience stats (last verified: _[date]_)
- Instagram followers: 940
- Average monthly Instagram reach: ~10,000 accounts
- Facebook audience network: 4,379 followers
- Website visitors: 1,222/month
- MyoCon (TMA) outreach: 470,000+ emails, 40% average open rate

## Standard brand-pitch sentence
"I'm open to structuring this as an affiliate partnership, product collaboration, or paid campaign depending on what aligns best with your current marketing initiatives."

## Agents (the team)
| Agent | Job | Reports to |
|---|---|---|
| Chief of Staff (he) | The only agent Alicia talks to. Daily brief, Sunday plan, assigns all work, hires new agents | Alicia |
| Head of Marketing | Social posts, campaigns, email list, follower growth | Chief of Staff |
| CFO | Revenue plan, pricing, forecasts, Friday numbers | Chief of Staff |
| Medical Research Lead | IIM/IBM research, health fact-checks, trial news | Chief of Staff |
| Brand Guardian | QA before anything goes public | Chief of Staff |
| Week Planner | Sunday plan at 4 hours a day | Chief of Staff |

Skills built: `inbox-triage`, `revenue-check`. Next: `follow-up-tracker`, CFO skills (see `revenue/cfo-interview.md`).
Later hires: pitch writer, sponsorship scout, opportunity scout, job search.

## Folder layout
```
disabled-company/
├── CLAUDE.md                ← the handbook (behaviors)
├── context/company-facts.md ← this file (facts)
├── .claude/agents/          ← one job description per agent
├── .claude/skills/          ← one folder per skill
├── revenue/                 ← ledger.csv, cfo-interview.md, revenue plans
├── reports/
├── content/
└── pitches/
```
